// SOS Popup Functions
function openSosPopup() {
    const overlay = document.getElementById('sosOverlay');
    const popup = document.getElementById('sosPopup');
    overlay.classList.add('active');
    popup.classList.add('active');
    document.getElementById('helpMessage').style.display = 'none';
}

function closeSosPopup() {
    const overlay = document.getElementById('sosOverlay');
    const popup = document.getElementById('sosPopup');
    overlay.classList.remove('active');
    popup.classList.remove('active');
}

function triggerSos() {
    const helpMessage = document.getElementById('helpMessage');
    helpMessage.style.display = 'block';
    helpMessage.classList.add('active');
    
    // Show notification
    const notification = document.createElement('div');
    notification.className = 'notification';
    notification.textContent = 'Help on the Way!';
    document.body.appendChild(notification);
    
    // Remove notification after 3 seconds
    setTimeout(() => {
        notification.remove();
        closeSosPopup();
    }, 3000);
}

// Close SOS popup when clicking overlay
document.getElementById('sosOverlay').addEventListener('click', closeSosPopup); 