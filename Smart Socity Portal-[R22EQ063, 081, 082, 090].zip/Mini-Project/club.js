// Demo clubs data
let clubs = [
    {
        id: 1,
        name: "Gardening Club",
        image: "images/gardening-club.jpg",
        description: "Join our vibrant community of garden enthusiasts! Learn sustainable gardening practices, share tips on growing organic vegetables, and participate in community garden projects. Perfect for both beginners and experienced gardeners.",
        isDemo: true
    },
    {
        id: 2,
        name: "Yoga Club",
        image: "images/yoga-club.jpg",
        description: "Find your inner peace with our daily yoga sessions. Expert instructors guide you through various yoga styles including Hatha, Vinyasa, and meditation. Suitable for all levels, join us for physical and mental wellness.",
        isDemo: true
    },
    {
        id: 3,
        name: "Zumba Club",
        image: "images/zumba-club.jpg",
        description: "Dance your way to fitness! Our energetic Zumba sessions combine Latin and international music with dance moves. Get fit, have fun, and join our passionate community of dance fitness enthusiasts.",
        isDemo: true
    },
    {
        id: 4,
        name: "Stock Club",
        image: "images/stock-club.jpg",
        description: "Learn about financial markets, investment strategies, and stock analysis. Regular workshops, market discussions, and investment tips from experienced traders. Build your knowledge of the financial world.",
        isDemo: true
    }
];

// Load from localStorage if available
const storedClubs = JSON.parse(localStorage.getItem('clubs'));
if (storedClubs) {
    clubs = storedClubs;
} else {
    localStorage.setItem('clubs', JSON.stringify(clubs));
}

// Render all clubs
function renderClubs() {
    const clubsGrid = document.getElementById('clubsGrid');
    clubsGrid.innerHTML = '';
    clubs.forEach(club => {
        const card = document.createElement('div');
        card.className = 'club-card';
        card.innerHTML = `
            <img src="${club.image}" alt="${club.name}" class="club-image">
            <div class="club-info">
                <h3 class="club-name">${club.name}</h3>
                <p class="club-description">${club.description}</p>
                <div class="club-actions">
                    <button class="signup-btn" onclick="openSignupPopup('${club.name}')">Sign Up</button>
                    ${(club.isDemo === false) ? `<button class="delete-btn" onclick="deleteClub(${club.id})"><i class='fas fa-trash'></i> Delete</button>` : ''}
                </div>
            </div>
        `;
        clubsGrid.appendChild(card);
    });
}

document.addEventListener('DOMContentLoaded', () => {
    renderClubs();
    setupEventListeners();
    // Image preview logic for Add Club popup
    const clubImageFile = document.getElementById('clubImageFile');
    const clubImagePreview = document.getElementById('clubImagePreview');
    if (clubImageFile) {
        clubImageFile.addEventListener('change', function() {
            if (this.files && this.files[0]) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    clubImagePreview.src = e.target.result;
                    clubImagePreview.style.display = 'block';
                };
                reader.readAsDataURL(this.files[0]);
            } else {
                clubImagePreview.src = '';
                clubImagePreview.style.display = 'none';
            }
        });
    }
});

// Add new club
function addClub(name, image, description) {
    const newClub = {
        id: Date.now(),
        name,
        image,
        description,
        isDemo: false
    };
    clubs.push(newClub);
    localStorage.setItem('clubs', JSON.stringify(clubs));
    renderClubs();
}

// Handle Add Club form submission
function handleAddClub(event) {
    event.preventDefault();
    const form = event.target;
    const name = document.getElementById('clubName').value;
    const imageFileInput = document.getElementById('clubImageFile');
    const imageFile = imageFileInput && imageFileInput.files[0];
    const description = document.getElementById('clubDescription').value;
    if (imageFile) {
        const reader = new FileReader();
        reader.onload = function(event) {
            addClub(name, event.target.result, description);
            closeAddClubPopup();
            showNotification('New club added successfully!');
            form.reset();
            document.body.style.overflow = '';
        };
        reader.readAsDataURL(imageFile);
    } else {
        showNotification('Please upload an image for the club.');
    }
}

// Delete club function
function deleteClub(clubId) {
    clubs = clubs.filter(club => club.id !== clubId);
    localStorage.setItem('clubs', JSON.stringify(clubs));
    renderClubs();
    showNotification('Club deleted successfully!');
}

// Function to show welcome notification
function showWelcomeNotification(clubName) {
    const notification = document.getElementById('welcomeNotification');
    const clubNameDisplay = document.getElementById('clubNameDisplay');
    
    // Set the club name
    clubNameDisplay.textContent = clubName;
    
    // Show the notification
    notification.classList.add('show');
    
    // Hide the notification after 3 seconds
    setTimeout(() => {
        notification.classList.remove('show');
    }, 3000);
}

// Handle signup form submission
function handleSignup(event) {
    event.preventDefault();
    
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const phone = document.getElementById('phone').value;
    const clubName = document.getElementById('signupClubName').textContent;

    if (!name || !email || !phone) {
        showNotification('Please fill in all fields');
        return;
    }

    // Show welcome notification with the club name
    showWelcomeNotification(clubName);

    // Close the popup
    closeSignupPopup();
    
    // Clear the form
    document.getElementById('signupForm').reset();
}

// Setup event listeners
function setupEventListeners() {
    document.getElementById('addClubForm').addEventListener('submit', handleAddClub);
    document.getElementById('signupForm').addEventListener('submit', handleSignup);
}

// Popup open/close functions (no overlay)
function openAddClubPopup() {
    document.getElementById('addClubPopup').classList.add('active');
    document.body.style.overflow = 'hidden';
}
function closeAddClubPopup() {
    document.getElementById('addClubPopup').classList.remove('active');
    document.body.style.overflow = '';
    document.getElementById('addClubForm').reset();
    document.getElementById('clubImagePreview').style.display = 'none';
}
function openSignupPopup(clubName) {
    document.getElementById('signupClubName').textContent = clubName;
    document.getElementById('signupPopup').classList.add('active');
    document.body.style.overflow = 'hidden';
}
function closeSignupPopup() {
    document.getElementById('signupPopup').classList.remove('active');
    document.body.style.overflow = '';
    document.getElementById('signupForm').reset();
}
// Notification
function showNotification(message) {
    const notification = document.createElement('div');
    notification.className = 'notification';
    notification.textContent = message;
    document.body.appendChild(notification);
    setTimeout(() => {
        notification.remove();
    }, 3000);
}
