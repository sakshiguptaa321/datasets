// Function to open the edit profile popup
function openEditProfilePopup() {
    document.getElementById('editProfileOverlay').classList.add('show');
    document.getElementById('editProfilePopup').classList.add('show');
}

// Function to close the edit profile popup
function closeEditProfilePopup() {
    document.getElementById('editProfileOverlay').classList.remove('show');
    document.getElementById('editProfilePopup').classList.remove('show');
}

// Function to save profile changes
function saveProfileChanges(event) {
    event.preventDefault();
    
    // Get form values
    const name = document.getElementById('editName').value;
    const phone = document.getElementById('editPhone').value;
    const email = document.getElementById('editEmail').value;
    const flat = document.getElementById('editFlat').value;
    
    // Update profile information
    document.querySelector('.profile-info h1').textContent = name;
    document.querySelector('.contact-item:nth-child(1) span').textContent = phone;
    document.querySelector('.contact-item:nth-child(2) span').textContent = email;
    document.querySelector('.contact-item:nth-child(3) span').textContent = flat;
    
    // Close the popup
    closeEditProfilePopup();
}

// Function to handle logout
function logout() {
    // Add any logout logic here (e.g., clearing session storage)
    window.location.href = 'index.html';
}

// Close popup when clicking outside
document.getElementById('editProfileOverlay').addEventListener('click', closeEditProfilePopup);

// Prevent popup from closing when clicking inside it
document.getElementById('editProfilePopup').addEventListener('click', (event) => {
    event.stopPropagation();
}); 