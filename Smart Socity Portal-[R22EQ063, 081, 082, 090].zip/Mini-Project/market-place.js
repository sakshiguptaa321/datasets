// Demo products with seller information
const DEMO_PRODUCTS = [
    {
        id: 1,
        name: "Sofa Set (3+2+1)",
        description: "Modern L-shaped sofa set in beige color, perfect for living room. Includes 3-seater, 2-seater, and 1-seater with premium fabric.",
        price: 45000,
        image: "https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=500",
        seller: "Rajesh Furniture",
        contact: "+91 98765 43210",
        email: "rajesh.furniture@gmail.com",
        isDemo: true
    },
    {
        id: 2,
        name: "LED TV 55\"",
        description: "Samsung 55-inch 4K Smart LED TV with HDR, perfect condition, 1 year old",
        price: 35000,
        image: "https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?w=500",
        seller: "Priya Sharma",
        contact: "+91 98765 43211",
        email: "priya.sharma@gmail.com",
        isDemo: true
    },
    {
        id: 3,
        name: "Honda Activa 125",
        description: "2022 model, single owner, 5000 km run, excellent condition, all papers available",
        price: 65000,
        image: "https://images.unsplash.com/photo-1558981806-ec527fa84c39?w=500",
        seller: "Vikram Singh",
        contact: "+91 98765 43212",
        email: "vikram.singh@gmail.com",
        isDemo: true
    },
    {
        id: 4,
        name: "Dining Table Set",
        description: "6-seater wooden dining table with chairs, teak wood finish, includes table cloth",
        price: 28000,
        image: "https://images.unsplash.com/photo-1577140917170-285929fb55b7?w=500",
        seller: "Meera Patel",
        contact: "+91 98765 43213",
        email: "meera.patel@gmail.com",
        isDemo: true
    },
    {
        id: 5,
        name: "Washing Machine",
        description: "IFB 7kg fully automatic washing machine, 2 years old, excellent condition",
        price: 15000,
        image: "https://images.unsplash.com/photo-1626806787461-102c1bfaaea1?w=500",
        seller: "Arun Kumar",
        contact: "+91 98765 43214",
        email: "arun.kumar@gmail.com",
        isDemo: true
    },
    {
        id: 6,
        name: "Bookshelf",
        description: "5-tier wooden bookshelf with glass doors, perfect for home library",
        price: 12000,
        image: "https://images.unsplash.com/photo-1507842217343-583bb7270b66?w=500",
        seller: "Neha Gupta",
        contact: "+91 98765 43215",
        email: "neha.gupta@gmail.com",
        isDemo: true
    },
    {
        id: 7,
        name: "Refrigerator",
        description: "Whirlpool 300L double door refrigerator, 1 year old, energy efficient",
        price: 22000,
        image: "https://images.unsplash.com/photo-1571175443880-49e1d25b2bc5?w=500",
        seller: "Suresh Reddy",
        contact: "+91 98765 43216",
        email: "suresh.reddy@gmail.com",
        isDemo: true
    },
    {
        id: 8,
        name: "Study Table",
        description: "Ergonomic study table with chair, perfect for students, includes LED lamp",
        price: 8000,
        image: "https://images.unsplash.com/photo-1518455027359-f3f8164ba6bd?w=500",
        seller: "Anita Desai",
        contact: "+91 98765 43217",
        email: "anita.desai@gmail.com",
        isDemo: true
    }
];

// State management
let products = [];
let likedProducts = new Set();

// Initialize the marketplace
function initializeMarketplace() {
    products = [...DEMO_PRODUCTS];
    likedProducts = new Set(JSON.parse(localStorage.getItem('likedProducts')) || []);
    renderProducts();
}

// Render products in grid
function renderProducts(targetGrid = 'product-grid', isLikedView = false) {
    const grid = document.getElementById(targetGrid);
    const productsToRender = isLikedView 
        ? products.filter(p => likedProducts.has(p.id))
        : products;

    grid.innerHTML = '';
    productsToRender.forEach(product => {
        grid.appendChild(createProductCard(product, isLikedView));
    });
}

// Create product card
function createProductCard(product, isLikedView = false) {
    const card = document.createElement('div');
    card.className = 'product-card';
    card.setAttribute('data-id', product.id);

    const formattedPrice = new Intl.NumberFormat('en-IN', {
        style: 'currency',
        currency: 'INR'
    }).format(product.price);

    if (isLikedView) {
        card.innerHTML = `
            <div class="card-inner">
                <div class="card-front">
                    <img src="${product.image}" alt="${product.name}" class="product-image">
                    <h3 class="product-title">${product.name}</h3>
                    <div class="product-price">${formattedPrice}</div>
                </div>
                <div class="card-back">
                    <div class="product-details">
                        <h3 class="product-title">${product.name}</h3>
                        <p class="product-description">${product.description}</p>
                        <div class="product-price">${formattedPrice}</div>
                        <div class="seller-info">
                            <div class="seller-name">
                                <i class="fas fa-user"></i>
                                ${product.seller}
                            </div>
                            <div class="seller-contact">
                                <i class="fas fa-phone"></i>
                                ${product.contact}
                            </div>
                            <div class="seller-email">
                                <i class="fas fa-envelope"></i>
                                ${product.email}
                            </div>
                        </div>
                        <div class="product-actions">
                            <button class="like-button liked" onclick="toggleLike(${product.id}); event.stopPropagation();">
            <i class="fas fa-heart"></i>
        </button>
                            <button class="remove-button" onclick="removeFromLiked(${product.id}); event.stopPropagation();">
                                <i class="fas fa-times"></i>
                                Remove
                            </button>
                        </div>
                        <button class="view-in-marketplace" onclick="scrollToProduct(${product.id}); event.stopPropagation();">
                            <i class="fas fa-external-link-alt"></i>
                            View in Marketplace
                        </button>
                    </div>
                </div>
            </div>
        `;

        // Add click event for card flipping
        const cardInner = card.querySelector('.card-inner');
        card.addEventListener('click', function(e) {
            // Only flip if not clicking on buttons
            if (!e.target.closest('button')) {
                card.classList.toggle('flipped');
            }
        });
    } else {
        // Original card layout for main product grid
        card.innerHTML = `
            <img src="${product.image}" alt="${product.name}" class="product-image">
            <div class="product-details">
                <h3 class="product-title">${product.name}</h3>
                <p class="product-description">${product.description}</p>
                <div class="product-price">${formattedPrice}</div>
                <div class="seller-info">
                    <div class="seller-name">
                        <i class="fas fa-user"></i>
                        ${product.seller}
                    </div>
                    <div class="seller-contact">
                        <i class="fas fa-phone"></i>
                        ${product.contact}
                    </div>
                    <div class="seller-email">
                        <i class="fas fa-envelope"></i>
                        ${product.email}
                    </div>
                </div>
                <div class="product-actions">
                    <button class="like-button ${likedProducts.has(product.id) ? 'liked' : ''}" 
                            onclick="toggleLike(${product.id})">
                        <i class="fa${likedProducts.has(product.id) ? 's' : 'r'} fa-heart"></i>
                    </button>
                    ${!product.isDemo ? `
                        <button class="delete-button" onclick="deleteProduct(${product.id})">
                            <i class="fas fa-trash"></i> Delete
                        </button>
                    ` : ''}
                </div>
            </div>
        `;
    }

    return card;
}

// Toggle like status
function toggleLike(productId) {
    const isLikedView = document.getElementById('liked-products-popup').classList.contains('active');
    const card = isLikedView ? 
        document.querySelector(`#liked-products-grid .product-card[data-id="${productId}"]`) : null;

    if (likedProducts.has(productId)) {
        likedProducts.delete(productId);
        if (card) {
            card.style.opacity = '0';
            card.style.transform = 'scale(0.8)';
            setTimeout(() => {
                renderProducts('liked-products-grid', true);
            }, 300);
        }
    } else {
        likedProducts.add(productId);
    }
    
    localStorage.setItem('likedProducts', JSON.stringify([...likedProducts]));
    
    // Update both views
    renderProducts();
    if (document.getElementById('liked-products-popup').classList.contains('active')) {
        renderProducts('liked-products-grid', true);
    }
}

// Delete product
function deleteProduct(productId) {
    if (confirm('Are you sure you want to delete this product?')) {
        products = products.filter(p => p.id !== productId);
        likedProducts.delete(productId);
        localStorage.setItem('likedProducts', JSON.stringify([...likedProducts]));
        renderProducts();
        if (document.getElementById('liked-products-modal').classList.contains('show')) {
            renderProducts('liked-products-grid', true);
        }
    }
}

// Modal functions
function openAddProductModal() {
    document.getElementById('add-product-modal').classList.add('show');
}

function closeAddProductModal() {
    document.getElementById('add-product-modal').classList.remove('show');
    document.getElementById('add-product-form').reset();
}

function openLikedProductsModal() {
    const modal = document.getElementById('liked-products-modal');
    modal.classList.add('show');
    renderProducts('liked-products-grid', true);
}

function closeLikedProductsModal() {
    document.getElementById('liked-products-modal').classList.remove('show');
}

// Popup functions
function toggleAddProductPopup() {
    const popup = document.getElementById('add-product-popup');
    popup.classList.toggle('active');
    
    if (!popup.classList.contains('active')) {
        document.getElementById('add-product-form').reset();
    }
}

function toggleLikedProductsPopup() {
    const popup = document.getElementById('liked-products-popup');
    popup.classList.toggle('active');
    
    if (popup.classList.contains('active')) {
        // Force re-render of liked products when opening popup
        renderProducts('liked-products-grid', true);
    }
}

// Add new function to handle removing from liked products
function removeFromLiked(productId) {
    const card = document.querySelector(`#liked-products-grid .product-card[data-id="${productId}"]`);
    if (card) {
        card.style.opacity = '0';
        card.style.transform = 'scale(0.8)';
        setTimeout(() => {
            likedProducts.delete(productId);
            localStorage.setItem('likedProducts', JSON.stringify([...likedProducts]));
            renderProducts();
            renderProducts('liked-products-grid', true);
        }, 300);
    }
}

// Add function to scroll to product in marketplace
function scrollToProduct(productId) {
    // Close the liked products popup
    document.getElementById('liked-products-popup').classList.remove('active');
    
    // Find the product card in the main grid
    const productCard = document.querySelector(`#product-grid .product-card[data-id="${productId}"]`);
    if (productCard) {
        // Add highlight effect
        productCard.classList.add('highlight');
        
        // Scroll to the product
        productCard.scrollIntoView({ behavior: 'smooth', block: 'center' });
        
        // Remove highlight after animation
        setTimeout(() => {
            productCard.classList.remove('highlight');
        }, 2000);
    }
}

// Handle add product form submission
document.addEventListener('DOMContentLoaded', function() {
    initializeMarketplace();

    document.getElementById('add-product-form').addEventListener('submit', function(e) {
        e.preventDefault();

        const formData = {
            id: Date.now(),
            name: document.getElementById('product-name').value,
            description: document.getElementById('product-description').value,
            price: parseInt(document.getElementById('product-price').value),
            seller: 'Current User',
            contact: '+91 98765 43216',
            email: 'user@gharnova.com',
            isDemo: false
        };

        const imageFile = document.getElementById('product-image').files[0];
        const reader = new FileReader();
        
        reader.onload = function(event) {
            formData.image = event.target.result;
            products.unshift(formData);
            renderProducts();
            toggleAddProductPopup();
        };

        reader.readAsDataURL(imageFile);
    });

    // Close popups when clicking outside
    document.addEventListener('click', function(event) {
        const addProductPopup = document.getElementById('add-product-popup');
        const likedProductsPopup = document.getElementById('liked-products-popup');
        
        if (event.target.closest('.popup-content') === null && 
            event.target.closest('.action-button') === null) {
            if (addProductPopup.classList.contains('active')) {
                toggleAddProductPopup();
            }
            if (likedProductsPopup.classList.contains('active')) {
                toggleLikedProductsPopup();
            }
        }
    });

    // Handle escape key
    document.addEventListener('keydown', function(event) {
        if (event.key === 'Escape') {
            const addProductPopup = document.getElementById('add-product-popup');
            const likedProductsPopup = document.getElementById('liked-products-popup');
            
            if (addProductPopup.classList.contains('active')) {
                toggleAddProductPopup();
            }
            if (likedProductsPopup.classList.contains('active')) {
                toggleLikedProductsPopup();
            }
        }
    });
});