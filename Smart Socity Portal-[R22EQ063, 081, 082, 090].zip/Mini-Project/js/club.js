// Function to show welcome notification
function showWelcomeNotification(clubName) {
    const notification = document.getElementById('welcomeNotification');
    const clubNameDisplay = document.getElementById('clubNameDisplay');
    
    // Set the club name
    clubNameDisplay.textContent = clubName;
    
    // Show the notification
    notification.classList.add('show');
    
    // Hide the notification after 3 seconds
    setTimeout(() => {
        notification.classList.remove('show');
    }, 3000);
}

// Function to open signup popup
function openSignupPopup(clubName) {
    const popup = document.getElementById('signupPopup');
    const signupClubName = document.getElementById('signupClubName');
    
    // Set the club name in the popup header
    signupClubName.textContent = clubName;
    
    // Show the popup
    popup.classList.add('active');
}

// Function to close signup popup
function closeSignupPopup() {
    const popup = document.getElementById('signupPopup');
    popup.classList.remove('active');
}

// Function to handle signup form submission
function signup(event) {
    event.preventDefault(); // Prevent form from submitting normally
    
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const phone = document.getElementById('phone').value;
    const clubName = document.getElementById('signupClubName').textContent;

    if (!name || !email || !phone) {
        alert('Please fill in all fields');
        return;
    }

    // Show welcome notification with the club name
    showWelcomeNotification(clubName);

    // Close the popup
    closeSignupPopup();
    
    // Clear the form
    document.getElementById('signupForm').reset();
}

// Add event listener to the signup form
document.addEventListener('DOMContentLoaded', function() {
    const signupForm = document.getElementById('signupForm');
    if (signupForm) {
        signupForm.addEventListener('submit', signup);
    }
}); 