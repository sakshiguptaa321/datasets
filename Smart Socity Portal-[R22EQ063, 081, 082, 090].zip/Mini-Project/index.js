// Toggle dropdown for Features
function toggleDropdown() {
  const dropdown = document.getElementById("featureDropdown");
  dropdown.classList.toggle("show");

  // Close the dropdown when the modal opens
  const modal = document.getElementById("rolemodal");
  if (modal.style.display === "block") {
    dropdown.classList.remove("show");
  }
}

// Open modal on login click
function openRoleModal() {
  document.getElementById("rolemodal").style.display = "block";

  // Close the dropdown when the modal opens
  document.getElementById("featureDropdown").classList.remove("show");
}

// Close the role modal
function closeModal() {
  document.getElementById("rolemodal").style.display = "none";
}

// Redirect to respective login pages based on role
function goToLogin(role) {
  console.log("Selected role:", role); // For debugging
  closeModal();

  if (role === "tenant") {
      window.location.href = "tenant-login.html";
  } 
  else if (role === "admin") {
      window.location.href = "admin-login.html";
  } 
  else if (role === "security") {
      window.location.href = "security-login.html";
  } 
  else if (role === "others") {
      window.location.href = "others-login.html";
  }
}

// Handle clicking outside for BOTH modal and dropdown
window.onclick = function (event) {
  // Close dropdown if clicked outside
  if (!event.target.matches('.features') && !event.target.matches('.dropdown-content') && !event.target.closest('.dropdown-content')) {
    let dropdowns = document.getElementsByClassName("dropdown-content");
    for (let i = 0; i < dropdowns.length; i++) {
      dropdowns[i].classList.remove('show');
    }
  }

  // Close role selection modal if clicked outside it
  const modal = document.getElementById("rolemodal");
  if (event.target === modal) {
    closeModal();
  }
};


  // Attach modal opening to all feature links
window.addEventListener("DOMContentLoaded", () => {
  const featureLinks = document.querySelectorAll(".dropdown-content a");
  featureLinks.forEach(link => {
      link.addEventListener("click", openRoleModal);
  });
});

window.addEventListener("DOMContentLoaded", function () {
  const visitorList = document.getElementById("visitor-list");
  const storedVisitors = JSON.parse(localStorage.getItem("visitors")) || [
      { id: 1, image: "images/sakshi.jpg", name: "Sakshi Gupta", status: "Pending" },
      { id: 2, image: "images/nidhi.jpg", name: "Nidhi N", status: "Pending" },
      { id: 3, image: "images/noah.jpg", name: "Peter Kavinsky", status: "Pending" }
  ];

  // Modal elements
  const modal = document.getElementById("visitorModal");
  const modalImage = document.getElementById("modalImage");
  const modalName = document.getElementById("modalName");
  const modalClose = document.querySelector(".modal .close");

  // Function to render visitors
  function renderVisitors() {
      visitorList.innerHTML = "";
      storedVisitors.forEach((visitor, index) => {
          const visitorItem = document.createElement("div");
          visitorItem.classList.add("visitor-item");
          visitorItem.innerHTML = `
              <img src="${visitor.image}" alt="Visitor Image" onclick="openModal(${index})">
              <span>${visitor.name}</span>
              <span class="status">${visitor.status}</span>
              <div class="actions">
                  ${visitor.status === 'Approved' 
                      ? '<span class="approved-label">✔️ Approved</span>' 
                      : visitor.status === 'Disapproved' 
                          ? '<span class="disapproved-label">❌ Disapproved</span>' 
                          : `
                              <button class="approve" onclick="updateStatus(${index}, 'Approved')">✔️ Approve</button>
                              <button class="disapprove" onclick="updateStatus(${index}, 'Disapproved')">❌ Disapprove</button>
                          `
                  }
              </div>
          `;
          visitorList.appendChild(visitorItem);
      });
  }

  // Open the modal with visitor details
  window.openModal = function (index) {
      const visitor = storedVisitors[index];
      modalImage.src = visitor.image;  // Set image in the modal
      modalName.textContent = visitor.name;  // Set name in the modal
      modal.style.display = "block";  // Display the modal
  }
  
  // Close the modal
  function closeModal() {
      modal.style.display = "none";  // Hide the modal
  }

  // Close modal when clicking outside of it
  window.onclick = function (event) {
      if (event.target === modal) {
          closeModal();  // Close the modal if clicked outside
      }
  };

  // Close modal on close button click
  modalClose.addEventListener("click", closeModal);

  // Update the status of the visitor
  window.updateStatus = function (index, status) {
      storedVisitors[index].status = status;
      localStorage.setItem("visitors", JSON.stringify(storedVisitors));
      alert(`${storedVisitors[index].name} has been ${status}`);
      renderVisitors();
  };

  // Secret Reset Button (Hidden)
  const resetButton = document.createElement("button");
  resetButton.textContent = "Reset Demo";
  resetButton.style.position = "fixed";
  resetButton.style.bottom = "10px";
  resetButton.style.right = "10px";
  resetButton.style.opacity = "0";
  resetButton.style.pointerEvents = "none";
  resetButton.style.transition = "opacity 0.3s";
  resetButton.addEventListener("click", () => {
      localStorage.removeItem("visitors");
      alert("Visitor statuses have been reset.");
      location.reload();
  });
  document.body.appendChild(resetButton);

  // Show button on special key combo
  window.addEventListener("keydown", (e) => {
      if (e.ctrlKey && e.altKey && e.key === "R") {
          resetButton.style.opacity = "1";
          resetButton.style.pointerEvents = "auto";
      }
  });

  // Initial render of visitors
  renderVisitors();
});


// AI-powered Complaint Categorization with NLP, Technician Assignment, and Sentiment Analysis
window.addEventListener("DOMContentLoaded", function () {
  const complaintForm = document.getElementById("complaint-form");
  const complaintsList = document.getElementById("complaints");
  let complaints = JSON.parse(localStorage.getItem("complaints")) || [];

  // Define categories and their associated keywords and technicians
  const categories = {
      "Plumbing": ["leak", "pipe", "water", "drip", "clog", "flood", "sewage", "tap", "sink"],
      "Electrical": ["electric", "wire", "wiring", "short", "circuit", "shock", "outlet", "light", "fuse", "switch"],
      "Maintenance": ["repair", "broken", "damage", "painting", "renovation", "fix", "replace", "maintenance"],
      "Noise": ["loud", "noise", "party", "disturbance", "shouting", "barking", "construction", "vibration"],
      "Security": ["theft", "suspicious", "unauthorized", "trespass", "break-in", "security", "intruder", "threat"],
      "Cleanliness": ["garbage", "trash", "dirty", "unhygienic", "sanitation", "clogged", "smell", "odor"],
      "Parking": ["parking", "space", "vehicle", "car", "blocked", "garage", "slot", "reservation"],
      "Other": [] // Fallback category
  };

  const technicianMap = {
      "Plumbing": "Plumber",
      "Electrical": "Electrician",
      "Maintenance": "Maintenance Team",
      "Noise": "Community Manager",
      "Security": "Security Team",
      "Cleanliness": "Cleaning Staff",
      "Parking": "Parking Manager",
      "Other": "General Support"
  };

  // Basic sentiment analysis for urgency detection
  const urgentWords = ["urgent", "immediate", "critical", "emergency", "important", "danger", "risk", "hazard", "quick", "asap", "now", "priority", "fast", "rapid"];

  // Function to extract keywords using improved NLP techniques
  function extractKeywords(description) {
      const words = description.toLowerCase().split(/\W+/);
      const extractedKeywords = new Set();
      let isUrgent = false;

      for (const word of words) {
          if (urgentWords.includes(word)) isUrgent = true;
          for (const [category, keywords] of Object.entries(categories)) {
              if (keywords.some(kw => word.includes(kw))) {
                  extractedKeywords.add(category);
              }
          }
      }

      return {
          keywords: extractedKeywords.size > 0 ? Array.from(extractedKeywords) : ["Other"],
          isUrgent: isUrgent
      };
  }

  // Function to handle form submission
  complaintForm.addEventListener("submit", function (e) {
      e.preventDefault();

      const name = document.getElementById("name").value;
      const email = document.getElementById("email").value;
      const phone = document.getElementById("phone").value;
      const flat = document.getElementById("flat").value;
      const floor = document.getElementById("floor").value;
      const complaintDetails = document.getElementById("complaint").value;

      // Extract keywords and determine category
      const { keywords, isUrgent } = extractKeywords(complaintDetails);
      const category = keywords[0];
      const assignedTechnician = technicianMap[category] || "General Support";

      // Validate inputs
      if (name && email && phone && flat && floor && complaintDetails) {
          // Create a new complaint object
          const newComplaint = {
              name: name,
              email: email,
              phone: phone,
              flat: flat,
              floor: floor,
              details: complaintDetails,
              keywords: keywords,
              category: category,
              technician: assignedTechnician,
              status: "Pending",
              priority: isUrgent ? "High" : "Normal"
          };

          // Add the new complaint to the complaints array
          complaints.push(newComplaint);
          localStorage.setItem("complaints", JSON.stringify(complaints));

          // Reset form fields
          complaintForm.reset();

          // Show success alert
          const popup = document.createElement("div");
          popup.classList.add("popup");
          popup.innerHTML = `<p>Complaint registered successfully under <strong>${category}</strong> category, assigned to <strong>${assignedTechnician}</strong>, with <strong>${isUrgent ? 'High' : 'Normal'}</strong> priority.</p>`;
          document.body.appendChild(popup);

          // Remove the popup after 3 seconds
          setTimeout(() => popup.remove(), 3000);

        }
  });
});


//Notice Board
// Load posts from localStorage and display them
function loadPosts() {
  const postContainer = document.getElementById("posts-container");
  const posts = JSON.parse(localStorage.getItem("posts")) || [];

  posts.forEach(post => {
      const postElement = createPostElement(post.content, post.timestamp);
      postContainer.prepend(postElement);
  });
}

// Function to handle posting
function addPost() {
  const textarea = document.getElementById("new-post");
  const content = textarea.value.trim();

  if (content !== "") {
      const postContainer = document.getElementById("posts-container");

      // Create a new post element
      const timestamp = Date.now();
      const post = { content, timestamp };

      // Save the post in localStorage
      const posts = JSON.parse(localStorage.getItem("posts")) || [];
      posts.unshift(post); // Add the new post to the top
      localStorage.setItem("posts", JSON.stringify(posts));

      // Display the new post
      const postElement = createPostElement(content, timestamp);
      postContainer.prepend(postElement);

      // Clear the textarea
      textarea.value = "";
  }
}

// Function to handle reactions
function reactToPost(element, emoji) {
    const countSpan = element.textContent.split(' ')[1];
    const currentCount = parseInt(countSpan) || 0;
    const newCount = currentCount + 1;
    element.textContent = `${emoji} ${newCount}`;
    
    // Store reaction in localStorage
    const postElement = element.closest('.post');
    const postContent = postElement.querySelector('.post-content').textContent;
    const reactions = JSON.parse(localStorage.getItem('postReactions')) || {};
    
    if (!reactions[postContent]) {
        reactions[postContent] = {};
    }
    if (!reactions[postContent][emoji]) {
        reactions[postContent][emoji] = 0;
    }
    reactions[postContent][emoji] = newCount;
    localStorage.setItem('postReactions', JSON.stringify(reactions));
}

// Function to create the post element
function createPostElement(content, timestamp) {
    const postElement = document.createElement("div");
    postElement.classList.add("post");
    
    const postHeader = document.createElement("div");
    postHeader.classList.add("post-header");
    
    const postAuthor = document.createElement("span");
    postAuthor.classList.add("post-author");
    postAuthor.textContent = "You";
    
    const postTime = document.createElement("span");
    postTime.classList.add("post-time");
    postTime.setAttribute("data-timestamp", timestamp);
    postTime.textContent = getTimeAgo(timestamp);
    
    postHeader.appendChild(postAuthor);
    postHeader.appendChild(postTime);
    
    const postContent = document.createElement("p");
    postContent.classList.add("post-content");
    postContent.textContent = content;
    
    const reactionBar = document.createElement("div");
    reactionBar.classList.add("reaction-bar");
    
    // Load saved reactions
    const reactions = JSON.parse(localStorage.getItem('postReactions')) || {};
    const postReactions = reactions[content] || {};
    
    reactionBar.innerHTML = `
        <span onclick="reactToPost(this, '❤️')">❤️ ${postReactions['❤️'] || 0}</span>
        <span onclick="reactToPost(this, '😂')">😂 ${postReactions['😂'] || 0}</span>
        <span onclick="reactToPost(this, '👍')">👍 ${postReactions['👍'] || 0}</span>
        <span onclick="reactToPost(this, '🎉')">🎉 ${postReactions['🎉'] || 0}</span>
    `;

    postElement.appendChild(postHeader);
    postElement.appendChild(postContent);
    postElement.appendChild(reactionBar);

    return postElement;
}

// Function to get time ago string
function getTimeAgo(timestamp) {
    const now = Date.now();
    const diff = now - timestamp;
    
    const seconds = Math.floor(diff / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);
    
    if (seconds < 60) {
        return "just now";
    } else if (minutes < 60) {
        return `${minutes} minute${minutes === 1 ? '' : 's'} ago`;
    } else if (hours < 24) {
        return `${hours} hour${hours === 1 ? '' : 's'} ago`;
    } else if (days < 7) {
        return `${days} day${days === 1 ? '' : 's'} ago`;
    } else {
        const date = new Date(timestamp);
        return date.toLocaleDateString();
    }
}

// Function to update all post times
function updatePostTimes() {
    const postTimes = document.querySelectorAll(".post-time");
    postTimes.forEach((postTime) => {
        const timestamp = parseInt(postTime.getAttribute("data-timestamp"), 10);
        postTime.textContent = getTimeAgo(timestamp);
    });
}

// Update times every minute
setInterval(updatePostTimes, 60000);

// Load posts when the page is loaded
window.onload = function() {
    loadPosts();
    updatePostTimes(); // Initial update of times
};

// Contact Form Handling
document.addEventListener('DOMContentLoaded', function() {
    const contactForm = document.getElementById('contactForm');
    
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            alert('Thank you! Your message has been sent successfully.');
            contactForm.reset();
        });
    }
});



